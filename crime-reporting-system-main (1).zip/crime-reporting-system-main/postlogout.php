<?php
if($_SERVER['REQUEST_METHOD']=='GET'){
    header("Location: Login.php");

 }
?>